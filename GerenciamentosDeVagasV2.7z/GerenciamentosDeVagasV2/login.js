document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    // Verifica o login
    fetch('https://crudcrud.com/api/73bc63ceaa0a40628f195118378ac7af/usuarios')
        .then(response => response.json())
        .then(usuarios => {
            const usuarioEncontrado = usuarios.find(user => user.email === email && user.senha === senha);

            if (usuarioEncontrado) {
                alert('Login realizado com sucesso!');
                sessionStorage.setItem('usuarioLogado', JSON.stringify(usuarioEncontrado));
                window.location.href = 'vaga.html';  // Redireciona para a página de cadastro de vagas
            } else {
                alert('Email ou senha incorretos!');
            }
        })
        .catch(error => console.error('Erro:', error));
});
