document.getElementById('cadastrarUsuario').addEventListener('click', () => {
    const usuario = {
        nome: document.getElementById('nome').value,
        sobrenome: document.getElementById('sobrenome').value,
        dataNascimento: document.getElementById('dataNascimento').value,
        email: document.getElementById('email').value,
        senha: document.getElementById('senha').value
    };

    fetch('https://crudcrud.com/api/73bc63ceaa0a40628f195118378ac7af/usuarios', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(usuario)
    })
    .then(response => response.json())
    .then(data => {
        alert('Usuário cadastrado com sucesso!');
        window.location.href = 'login.html';
    })
    .catch(error => console.error('Erro ao cadastrar usuário:', error));
});
