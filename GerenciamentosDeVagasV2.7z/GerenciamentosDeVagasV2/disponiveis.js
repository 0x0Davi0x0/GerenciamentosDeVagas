const apiURLVagas = 'https://crudcrud.com/api/73bc63ceaa0a40628f195118378ac7af/vagas';

// Carregar vagas disponíveis
function carregarVagasDisponiveis() {
    fetch(apiURLVagas)
        .then(response => response.json())
        .then(data => {
            const totalVagas = 50; // Exemplo de total de vagas
            const vagasOcupadas = data.length;
            const vagasDisponiveis = totalVagas - vagasOcupadas;

            document.getElementById('vagasDisponiveis').textContent = 
                `Total de vagas disponíveis: ${vagasDisponiveis}`;
        })
        .catch(error => console.error('Erro ao carregar vagas disponíveis:', error));
}

// Carregar vagas ao iniciar a página
window.onload = carregarVagasDisponiveis;

window.onload = function() {
    const usuarioLogado = sessionStorage.getItem('usuarioLogado');
    if (!usuarioLogado) {
        alert('Você precisa estar logado para acessar esta página.');
        window.location.href = 'login.html';  // Redireciona para o login
    }
};

